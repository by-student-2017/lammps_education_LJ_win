Hello dear README reader,

You can find in this folder two versions of a fix that allow to quickly create  equilibrated polymer melts.
The folder contains the following files, excluding the one you are reading:
	- /rlp7jan14/fix_rlp.cpp
	- /rlp7jan14/fix_rlp.h
	- /rlp15apr16/fix_rlp.cpp
	- /rlp15apr16/fix_rlp.h theses files are the ones to be included in lammps. Two versions are avaliable: one working with Lammps 7 january 2014 version and the other with 15 april 2016 version
	- fix_rlp.txt and fix_rlp.html the Lammps documentation for fix RLP, to add in the doc/file
	- test_input.txt a exemple script
	- Polymer2000.dat input data for test_input.txt
	- rlp10outof100.avi a visual exemple of what this fix does

INSTALLATION ON LINUX

- Copy fix_rlp.cpp and fix_rlp.h in the /src folder of corresponding Lammps version
- On a terminal, type "make serial" if you want the serial version or "make mpi" if you want the parallel one
- A executable file is now available in the /src folder

To improve the fix efficiency, it's possible to end the run when the last chain have reached the fixed length. For this feature to happen, the line "if (i >= update->nsteps) break;" have to be included in verlet.cpp at the beginning of the run loop (line 229 for 7jan14 version and line 232 for 15apr16 version)
