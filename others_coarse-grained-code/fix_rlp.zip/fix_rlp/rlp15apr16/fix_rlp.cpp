/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

#include <math.h>
#include <mpi.h>
#include <string.h>
#include <stdlib.h>
#include "fix_rlp.h"
#include "update.h"
#include "respa.h"
#include "atom.h"
#include "atom_vec.h"
#include "force.h"
#include "pair.h"
#include "comm.h"
#include "neighbor.h"
#include "neigh_list.h"
#include "neigh_request.h"
#include "random_mars.h"
#include "memory.h"
#include "error.h"
#include <iostream>

using namespace LAMMPS_NS;
using namespace FixConst;

#define BIG 1.0e20
#define DELTA 16

/* ---------------------------------------------------------------------- */

/*This fix create a melt of linear polymere molecules from a monomer bath*/

/*fix ID group-ID rlp nevery monomer-ID radical-ID internal-ID Rmin bondtype lmax 
 and optional keywords :
 prob fraction seed
 maxbound bmax*/

FixRLP::FixRLP(LAMMPS *lmp, int narg, char **arg) :
  Fix(lmp, narg, arg)
{
  if (narg < 10) error->all(FLERR,"Illegal fix rlp command");

  MPI_Comm_rank(world,&me);

  nevery = force->inumeric(FLERR,arg[3]);
  if (nevery <= 0) error->all(FLERR,"Illegal fix rlp command");

  bigint natoms = atom->natoms;
	
  force_reneighbor = 1;
  next_reneighbor = -1;
  vector_flag = 1;
  size_vector = 2;
  global_freq = 1;
  extvector = 0;

  lontype = force->inumeric(FLERR,arg[4]);
  radtype = force->inumeric(FLERR,arg[5]);
  intype = force->inumeric(FLERR,arg[6]);
  double cutoff = force->numeric(FLERR,arg[7]);
  btype = force->inumeric(FLERR,arg[8]);
  lmax = force->inumeric(FLERR,arg[9]);

  if (lontype < 1 || lontype > atom->ntypes ||
		radtype < 1 || radtype > atom->ntypes ||
		intype < 1 || intype > atom->ntypes)
		error->all(FLERR,"Invalid atom type in fix rlp command");
  if (cutoff < 0.0) error->all(FLERR,"Illegal fix rlp command");
  if (btype < 1 || btype > atom->nbondtypes)
    error->all(FLERR,"Invalid bond type in fix rlp command");

  cutsq = cutoff*cutoff;

  // optional keywords

  bmax = 5;
  fraction = 1.0;
  int seed = 12345;

  int iarg = 10;
  while (iarg < narg) {
		if (strcmp(arg[iarg],"prob") == 0) {
		  if (iarg+3 > narg) error->all(FLERR,"Illegal fix rlp command");
		  fraction = force->numeric(FLERR,arg[iarg+1]);
			seed = force->inumeric(FLERR,arg[iarg+2]);
		  if (fraction < 0.0 || fraction > 1.0)
				error->all(FLERR,"Illegal fix rlp command");
		  if (seed <= 0) error->all(FLERR,"Illegal fix rlp command");
				iarg += 3;
		} else if (strcmp(arg[iarg],"maxbound") == 0) {
			if (iarg+2 > narg) error->all(FLERR,"Illegal fix rlp command");
			bmax = force->numeric(FLERR,arg[iarg+1]);
			iarg += 2;
    } else error->all(FLERR,"Illegal fix rlp command");
  }

  // error check

  if (atom->molecular != 1)
    error->all(FLERR,"Cannot use fix rlp with non-molecular systems");
  
  // initialize Marsaglia RNG with processor-unique seed

  random = new RanMars(lmp,seed + me);

  // perform initial allocation of atom-based arrays
  // register with Atom class
  // bondcount values will be initialized in setup()

  bondcount = NULL;
  grow_arrays(atom->nmax);
  atom->add_callback(0);
  countflag = 0;

  // set comm sizes needed by this fix

  comm_forward = MAX(2,2+atom->maxspecial);
  comm_reverse = 2;

  // allocate arrays local to this fix

  nmax = 0;
  partner = finalpartner = NULL;
  distsq = NULL;
  
  maxcreate = 0;


  // zero out stats

  createcount = 0;
  createcounttotal = 0;
	
}

/* ---------------------------------------------------------------------- */

FixRLP::~FixRLP()
{
  // unregister callbacks to this fix from Atom class

  atom->delete_callback(id,0);

  delete random;

  // delete locally stored arrays

  memory->destroy(bondcount);
  memory->destroy(partner);
  memory->destroy(finalpartner);
  memory->destroy(distsq);
}

/* ---------------------------------------------------------------------- */

int FixRLP::setmask()
{
  int mask = 0;
  mask |= POST_INTEGRATE;
  mask |= POST_INTEGRATE_RESPA;
  return mask;
}

/* ---------------------------------------------------------------------- */

void FixRLP::init()
{
  if (strstr(update->integrate_style,"respa"))
    nlevels_respa = ((Respa *) update->integrate)->nlevels;
  
  // check cutoff for lontype,radtype
	
  if (force->pair == NULL || cutsq > force->pair->cutsq[lontype][radtype])
	error->all(FLERR,"Fix rlp cutoff is longer than pairwise cutoff");
	
  // require special bonds = 0,1,1

  if (force->special_lj[1] != 0.0 || force->special_lj[2] != 1.0 ||
      force->special_lj[3] != 1.0)
    error->all(FLERR,"Fix rlp requires special_bonds lj = 0,1,1");

  if (atom->q_flag)
    if (force->special_coul[1] != 0.0 || force->special_coul[2] != 1.0 ||
        force->special_coul[3] != 1.0)
      error->all(FLERR,"Fix rlp requires special_bonds coul = 0,1,1");

  // warn if angles, dihedrals, impropers are being used

  if (force->angle || force->dihedral || force->improper) {
    if (me == 0)
      error->warning(FLERR,"Created bonds will not create angles, "
                     "dihedrals, or impropers");
  }

  // need a half neighbor list, built when ever re-neighboring occurs

  int irequest = neighbor->request((void *) this);
  neighbor->requests[irequest]->pair = 0;
  neighbor->requests[irequest]->fix = 1;
  neighbor->requests[irequest]->occasional = 1;

  lastcheck = -1;
}

/* ---------------------------------------------------------------------- */

void FixRLP::init_list(int id, NeighList *ptr)
{
  list = ptr;
}

/* ---------------------------------------------------------------------- */

void FixRLP::setup(int vflag)
{
  int i,j,m;
  
  // compute initial bondcount if this is first run
  // can't do this earlier, like in constructor or init, b/c need ghost info

  if (countflag) return;
  countflag = 1;

  // count bonds stored with each bond I own
  // if newton bond is not set, just increment count on atom I
  // if newton bond is set, also increment count on atom J even if ghost
  // bondcount is long enough to tally ghost atom counts

  int *num_bond = atom->num_bond;
  int **bond_type = atom->bond_type;
  tagint **bond_atom = atom->bond_atom;
  int nlocal = atom->nlocal;
  int nghost = atom->nghost;
  int nall = nlocal + nghost;
  int newton_bond = force->newton_bond;

  for (i = 0; i < nall; i++) bondcount[i] = 0;

  for (i = 0; i < nlocal; i++) {
    for (j = 0; j < num_bond[i]; j++) {
      if (bond_type[i][j] == btype) {
        bondcount[i]++;
        if (newton_bond) {
          m = atom->map(bond_atom[i][j]);
          if (m < 0)
            error->one(FLERR,"Fix rlp needs ghost atoms "
                       "from further away");
          bondcount[m]++;
        }
      }
    }
  }

  // if newton_bond is set, need to sum bondcount
  commflag = 1;
  if (newton_bond) comm->reverse_comm_fix(this,1);
	
  //loop to create molecule to molecule_size map
  tagint *molecule = atom->molecule;
  std::map<tagint,int>::iterator iter;
  int tmp, max, nbproc;
  int *tab = NULL, *taball = NULL;

  MPI_Comm_size(world,&nbproc);
	
  //local initialisation of the map
  for (i = 0; i < nlocal; i++) {
		mol_size[molecule[i]] = 0;
  }
	
  for (i = 0; i < nlocal; i++) {
		mol_size[molecule[i]]++;
  }


  //molecules counting
  tmp = mol_size.size();
	
  MPI_Allreduce(&tmp,&max,1,MPI_INT,MPI_MAX,world);
  max++;
  i = 0;
  tab = (int *) malloc(max * sizeof(int));
  tab[0] = tmp;
  for (iter = mol_size.begin(); iter != mol_size.end(); ++iter){
		i++;
		tab[i] = iter->first;
  }
  while (i < max-1) {
		i++;
		tab[i] = -1;
  }
	
  taball = (int *) malloc(max * nbproc * sizeof(int));
  MPI_Allgather(tab,max,MPI_INT,taball,max,MPI_INT,world);

  //end of map initialisation
  for (i = 0 ; i < nbproc; i++) {
		m = taball[i*max];
		for (j = 0; j < m; j++) {
		  if ((taball[i*max+j+1] != -1) &&
		  		(mol_size.find(taball[i*max+j+1]) == mol_size.end())) {
				mol_size[taball[i*max+j+1]] = 0;
		  }
		}
  }
	
	if (me == 0) std::cout<<"Molecule Molecule_size : "<<std::endl;
  for (iter = mol_size.begin(); iter != mol_size.end(); ++iter) {
		MPI_Allreduce(&(iter->second),&tmp,1,MPI_INT,MPI_SUM,world);
		iter->second = tmp;
	  if (me == 0) std::cout<<"("<<iter->first<<" "<<iter->second<<")   ";
  }
	if (me == 0) std::cout<<std::endl;
	
  free(tab);
  free(taball);
}

/* ---------------------------------------------------------------------- */

void FixRLP::post_integrate()
{
  int i,j,k,m,n,ii,jj,inum,jnum,itype,jtype,n1,n2,n3,possible,tmp,nbproc;
  double xtmp,ytmp,ztmp,delx,dely,delz,rsq;
  int *ilist,*jlist,*numneigh,**firstneigh;
  tagint *slist;
  std::map<tagint,int>::iterator iter;
  MPI_Comm_size(world,&nbproc);

  if (update->ntimestep % nevery) return;

  // need updated ghost atom positions

  comm->forward_comm();

  // forward comm of bondcount, so ghosts have it

  commflag = 1;
  comm->forward_comm_fix(this,1);

  // resize bond partner list and initialize it
  // probability array overlays distsq array
  // needs to be atom->nmax in length

  if (atom->nmax > nmax) {
    memory->destroy(partner);
	memory->destroy(finalpartner);
    memory->destroy(distsq);
    nmax = atom->nmax;
    memory->create(partner,nmax,"rlp:partner");
	memory->create(finalpartner,nmax,"rlp:finalpartner");
    memory->create(distsq,nmax,"rlp:distsq");
    probability = distsq;
  }

  int nlocal = atom->nlocal;
  int nall = atom->nlocal + atom->nghost;

  for (i = 0; i < nall; i++) {
    partner[i] = 0;
	finalpartner[i] = 0;
    distsq[i] = BIG;
  }

  // loop over neighbors of my atoms
  // each atom sets one closest eligible partner atom ID to bond with

  double **x = atom->x;
  tagint *tag = atom->tag;
  tagint **bond_atom = atom->bond_atom;
  int *num_bond = atom->num_bond;
  int **nspecial = atom->nspecial;
  tagint **special = atom->special;
  int *mask = atom->mask;
  int *type = atom->type;
  tagint *molecule = atom->molecule;

  neighbor->build_one(list,1);
  inum = list->inum;
  ilist = list->ilist;
  numneigh = list->numneigh;
  firstneigh = list->firstneigh;

  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    if (!(mask[i] & groupbit)) continue;
    itype = type[i];
    xtmp = x[i][0];
    ytmp = x[i][1];
    ztmp = x[i][2];
    jlist = firstneigh[i];
    jnum = numneigh[i];

    for (jj = 0; jj < jnum; jj++) {
      j = jlist[jj];
      j &= NEIGHMASK;
      if (!(mask[j] & groupbit)) continue;
      jtype = type[j];

	  //conditions to allow polymerization step
		
	  possible = 0;
	  if (itype == radtype && jtype == lontype) {
			if (mol_size[molecule[i]] < lmax) {
			  possible = 1;
			}
	  } else if (itype == lontype && jtype == radtype) {
			if (mol_size[molecule[j]] < lmax) {
			  possible = 1;
			}
	  }
	  if (!possible) continue;
	  
	  // do not allow a duplicate bond to be created
      // check 1-2 neighbors of atom I

      for (k = 0; k < nspecial[i][0]; k++)
        if (special[i][k] == tag[j]) possible = 0;
      if (!possible) continue;

      delx = xtmp - x[j][0];
      dely = ytmp - x[j][1];
      delz = ztmp - x[j][2];
      rsq = delx*delx + dely*dely + delz*delz;
      if (rsq >= cutsq) continue;

      if (rsq < distsq[i]) {
        partner[i] = tag[j];
        distsq[i] = rsq;
      }
      if (rsq < distsq[j]) {
        partner[j] = tag[i];
        distsq[j] = rsq;
      }
    }
  }

  // reverse comm of distsq and partner
  // not needed if newton_pair off since I,J pair was seen by both procs

  commflag = 2;
  if (force->newton_pair) comm->reverse_comm_fix(this);

  // each atom now knows its winning partner
  // for prob check, generate random value for each atom with a bond partner
  // forward comm of partner and random value, so ghosts have it

  if (fraction < 1.0) {
    for (i = 0; i < nlocal; i++)
      if (partner[i]) probability[i] = random->uniform();
  }

  commflag = 2;
  comm->forward_comm_fix(this,2);

  // create bonds for atoms I own
  // if other atom is owned by another proc, it should create same bond
  // if both atoms list each other as winning bond partner
  // and probability constraint is satisfied

  int **bond_type = atom->bond_type;
  int newton_bond = force->newton_bond;
  	
  //mol_size copy creation
  std::map<tagint,int> copy_mol_size;
  copy_mol_size = mol_size;
  int nmol = mol_size.size();
  tagint tag_inhib;

  ncreate = 0;
  for (i = 0; i < nlocal; i++) {
    if (partner[i] == 0) continue;
    j = atom->map(partner[i]);
    if (partner[j] != tag[i]) continue;
	itype = type[i];
	jtype = type[j];
	

	//condition to limit molecule size and avoid molecule fusion
	
		if (inhib.find(tag[i]) != inhib.end() ||
			inhib.find(tag[j]) != inhib.end()) {
			//std::cout<<tag[i]<<"X["<<molecule[i]<<"]X"<<tag[j]<<"   ";
			continue;
		}
	
		if (itype == radtype && jtype == lontype) {
	  	if (mol_size[molecule[i]] == lmax) continue;
		} else if (jtype == radtype && itype == lontype) {
	  	if (mol_size[molecule[j]] == lmax) continue;
		}
	  
    // apply probability constraint using RN for atom with smallest ID

    if (fraction < 1.0) {
      if (tag[i] < tag[j]) {
        if (probability[i] >= fraction) continue;
      } else {
        if (probability[j] >= fraction) continue;
      }
    }
	  
	//radical transmission and molecule size increase
	//if (tag[i] < tag[j]) {
		if (itype == radtype && jtype == lontype) {
			if (mol_size[molecule[i]] != 1) type[i] = intype;
			mol_size[molecule[i]]++;
			mol_size[molecule[j]]--;
			type[j] = radtype;
			molecule[j] = molecule[i];
		} else if (j >= nlocal && itype == lontype && jtype == radtype) {
			//std::cout<<tag[i]<<"<fantome   ";
			type[i] = radtype;
			molecule[i] = molecule[j];
		}

	  
	  
    // if newton_bond is set, only store with I or J
    // if not newton_bond, store bond with both I and J

    if (!newton_bond || tag[i] < tag[j]) {
      if (num_bond[i] == atom->bond_per_atom)
        error->one(FLERR,"New bond exceeded bonds per atom in fix rlp");
      bond_type[i][num_bond[i]] = btype;
      bond_atom[i][num_bond[i]] = tag[j];
      num_bond[i]++;
    }


    // store final created bond partners and count the created bond once

    finalpartner[i] = tag[j];
    finalpartner[j] = tag[i];
    if (tag[i] < tag[j]) ncreate++;
  }
	
  //update the map mol_size
  
  for (iter = mol_size.begin(); iter != mol_size.end(); ++iter) {
		m = iter->second - copy_mol_size[iter->first];
		MPI_Allreduce(&m,&tmp,1,MPI_INT,MPI_SUM,world);
		iter->second = tmp + copy_mol_size[iter->first];
	
		//turn off one of the radical if the molecule reach lmax - 1
	
		if (iter->second == lmax - 1) {
			MPI_Status status;
		
			tag_inhib = -1;
		  j = 0;
		  while ((j < nbproc) && (ending_mol.find(iter->first) == ending_mol.end())) {
		  	if (me == j) {
				  i = 0;
				  while ((i < nlocal) && (tag_inhib == -1)) {
						if ((type[i] == radtype) && (molecule[i] == iter->first)) {
							inhib.insert(tag[i]);
							tag_inhib = tag[i];
							ending_mol.insert(molecule[i]);
				    }
						i++;
			  	}
					//sending of the inhibited radical tag by its owner
					for (i = 0;i < nbproc; i++){
						if (me != i) MPI_Send(&tag_inhib,1,MPI_INT,i,me,world);
					}
				} else {
				//reception by the other procs
  				MPI_Recv(&tag_inhib,1,MPI_INT,j,j,world,&status);
  				if (tag_inhib != -1) {
  					ending_mol.insert(iter->first);
  					inhib.insert(tag_inhib);
  				}
				}
				j++;
	  	}
		}
  }
  

  // tally stats
	
	//bool complete = true;
	if (me == 0) {
		std::cout<<std::endl;
		std::cout<<"Molecule Molecule_size :"<<std::endl;
		for (iter = mol_size.begin(); iter != mol_size.end(); ++iter) {
			std::cout<<"("<<iter->first<<" "<<iter->second<<")   ";
			//complete = complete && (iter->second >= lmax);
		}
		std::cout<<std::endl<<std::endl;
	}
		
  MPI_Allreduce(&ncreate,&createcount,1,MPI_INT,MPI_SUM,world);
  createcounttotal += createcount;
  atom->nbonds += createcount;
	
	

  // trigger reneighboring if any bonds were formed

  if (createcount) next_reneighbor = update->ntimestep;
  if (!createcount) return;
  
  // communicate final partner and 1-2 special neighbors
  // 1-2 neighs already reflect created bonds

  commflag = 3;
  comm->forward_comm_fix(this);
  
  //trigger end of run if all molecules are completed
  //not perfect, imply one molecule and one alone, is dedicated to the monomere bath and all the other are linear and in one piece 
  
  if (createcounttotal == (mol_size.size()-1)*(lmax-1)) {
  		std::cout<<"All molecules completed: end of run"<<std::endl;
  		update->laststep = update->ntimestep;
  		update->endstep = update->laststep;
  		update->nsteps = update->laststep - update->firststep; 
  }	

}

/* ----------------------------------------------------------------------
   insure all atoms 2 hops away from owned atoms are in ghost list
   this allows dihedral 1-2-3-4 to be properly created
     and special list of 1 to be properly updated
   if I own atom 1, but not 2,3,4, and bond 3-4 is added
     then 2,3 will be ghosts and 3 will store 4 as its finalpartner
------------------------------------------------------------------------- */

void FixRLP::check_ghosts()
{
  int i,j,n;
  tagint *slist;

  int **nspecial = atom->nspecial;
  tagint **special = atom->special;
  int nlocal = atom->nlocal;

  int flag = 0;
  for (i = 0; i < nlocal; i++) {
    slist = special[i];
    n = nspecial[i][1];
    for (j = 0; j < n; j++)
      if (atom->map(slist[j]) < 0) flag = 1;
  }

  int flagall;
  MPI_Allreduce(&flag,&flagall,1,MPI_INT,MPI_SUM,world);
  if (flagall)
    error->all(FLERR,"Fix rlp needs ghost atoms from further away");
  lastcheck = update->ntimestep;
}


/* ---------------------------------------------------------------------- */

void FixRLP::post_integrate_respa(int ilevel, int iloop)
{
  if (ilevel == nlevels_respa-1) post_integrate();
}


/* ---------------------------------------------------------------------- */

int FixRLP::pack_forward_comm(int n, int *list, double *buf,
                                     int pbc_flag, int *pbc)
{
  int i,j,k,m,ns;

  m = 0;

  if (commflag == 1) {
    for (i = 0; i < n; i++) {
      j = list[i];
      buf[m++] = ubuf(bondcount[j]).d;
    }
    return m;
  }

  if (commflag == 2) {
    for (i = 0; i < n; i++) {
      j = list[i];
      buf[m++] = ubuf(partner[j]).d;
      buf[m++] = probability[j];
    }
    return m;
  }

  int **nspecial = atom->nspecial;
  tagint **special = atom->special;

  m = 0;
  for (i = 0; i < n; i++) {
    j = list[i];
    buf[m++] = ubuf(finalpartner[j]).d;
    ns = nspecial[j][0];
    buf[m++] = ubuf(ns).d;
    for (k = 0; k < ns; k++)
      buf[m++] = ubuf(special[j][k]).d;
  }
  return m;
}

/* ---------------------------------------------------------------------- */

void FixRLP::unpack_forward_comm(int n, int first, double *buf)
{
  int i,j,m,ns,last;

  m = 0;
  last = first + n;

  if (commflag == 1) {
    for (i = first; i < last; i++)
      bondcount[i] = (int) ubuf(buf[m++]).i;

  } else if (commflag == 2) {
    for (i = first; i < last; i++) {
      partner[i] = (tagint) ubuf(buf[m++]).i;
      probability[i] = buf[m++];
    }

  } else {
    int **nspecial = atom->nspecial;
    tagint **special = atom->special;

    m = 0;
    last = first + n;
    for (i = first; i < last; i++) {
      finalpartner[i] = (tagint) ubuf(buf[m++]).i;
      ns = (int) ubuf(buf[m++]).i;
      nspecial[i][0] = ns;
      for (j = 0; j < ns; j++)
        special[i][j] = (tagint) ubuf(buf[m++]).i;
    }
  }
}


/* ---------------------------------------------------------------------- */

int FixRLP::pack_reverse_comm(int n, int first, double *buf)
{
  int i,m,last;

  m = 0;
  last = first + n;
  
  if (commflag == 1) {
    for (i = first; i < last; i++)
      buf[m++] = ubuf(bondcount[i]).d;
    return m;
  }

  for (i = first; i < last; i++) {
    buf[m++] = ubuf(partner[i]).d;
    buf[m++] = distsq[i];
  }
  return m;
}

/* ---------------------------------------------------------------------- */

void FixRLP::unpack_reverse_comm(int n, int *list, double *buf)
{
  int i,j,m;

  m = 0;

  if (commflag == 1) {
    for (i = 0; i < n; i++) {
      j = list[i];
      bondcount[j] += (int) ubuf(buf[m++]).i;
    }

  } else {
    for (i = 0; i < n; i++) {
      j = list[i];
      if (buf[m+1] < distsq[j]) {
        partner[j] = (tagint) ubuf(buf[m++]).i;
        distsq[j] = buf[m++];
      } else m += 2;
    }
  }
}

/* ----------------------------------------------------------------------
   allocate local atom-based arrays
------------------------------------------------------------------------- */

void FixRLP::grow_arrays(int nmax)
{
  memory->grow(bondcount,nmax,"rlp:bondcount");
}

/* ----------------------------------------------------------------------
   copy values within local atom-based arrays
------------------------------------------------------------------------- */

void FixRLP::copy_arrays(int i, int j, int delflag)
{
  bondcount[j] = bondcount[i];
}

/* ----------------------------------------------------------------------
   pack values in local atom-based arrays for exchange with another proc
------------------------------------------------------------------------- */

int FixRLP::pack_exchange(int i, double *buf)
{
  buf[0] = bondcount[i];
  return 1;
}

/* ----------------------------------------------------------------------
   unpack values in local atom-based arrays from exchange with another proc
------------------------------------------------------------------------- */

int FixRLP::unpack_exchange(int nlocal, double *buf)
{
  bondcount[nlocal] = static_cast<int> (buf[0]);
  return 1;
}

/* ---------------------------------------------------------------------- */


double FixRLP::compute_vector(int n)
{
  if (n == 1) return (double) createcount;
  return (double) createcounttotal;
}


/* ----------------------------------------------------------------------
   memory usage of local atom-based arrays
------------------------------------------------------------------------- */

double FixRLP::memory_usage()
{
  int nmax = atom->nmax;
  double bytes = nmax*2 * sizeof(int);
  bytes += nmax * sizeof(double);
  return bytes;
}
